import React, { PureComponent } from 'react'

import Carousel from './Carousel'
//styling
import './Landing.css'

export default class Landing extends PureComponent {
    render() {
        return (<div >
        <Carousel></Carousel>
      </div>
        )
    }
}
