import React, { PureComponent } from 'react'

class Settings extends PureComponent {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default Settings
