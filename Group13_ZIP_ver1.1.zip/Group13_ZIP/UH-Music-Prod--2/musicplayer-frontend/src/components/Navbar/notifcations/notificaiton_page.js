import React, { Component } from 'react'

class NotificationPage extends React.Component
{
    render()
    {
        return(<h1>
            Notification
        </h1>)
    }
}

export default NotificationPage


