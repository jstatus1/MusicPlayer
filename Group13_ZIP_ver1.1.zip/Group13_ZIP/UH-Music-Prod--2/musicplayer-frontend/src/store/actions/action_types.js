
// Types of actions
export const SUCCESS = "SUCCESS"

export const FAILURE = "FAILURE"

export const FETCH_USER = 'FETCH_USER';

