export const SUCCESS = "SUCCESS"
export const FAILURE = "FAILURE"